epl3 = read.csv("Attributes.csv", header = TRUE, na.strings = c(""), stringsAsFactors = T)
summary(epl3)
str(epl3)

library(gmodels)
library(ggplot2)
library(reshape2)
library(e1071)
library(caret)
library(pscl)

index <- sample(1:dim(epl3)[1], dim(epl3)[1] * .80, replace=FALSE)
training <- epl3[index, ]
testing <- epl3[-index, ]

set.seed(28022020)
epl3.train.index <- sample(1:nrow(epl3),ceiling(0.75*nrow(epl3)))
epl3.train <- epl3[epl3.train.index,]
epl3.test <- epl3[-epl3.train.index,]
str(epl3)
rpart.Control <- rpart.control(
  minsplit = 20,
  xval = 10
)

fit.rpart <- rpart(
  Age ~ .,
  data = epl3.train,
  method='anova',
  control = rpart.Control
)

fit.rpart

prp(fit.rpart, faclen = 0, cex = 0.8, extra = 1)

rpart.predict <- predict(
  fit.rpart,
  epl3.test[, -1]
)

print(fit.rpart)
fit.rpart$cptable

RMSE(pred = rpart.predict, obs = epl3.test$Overall)
print(rpart.predict)


