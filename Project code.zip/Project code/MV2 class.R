epl2 = read.csv("values2.csv", header = TRUE, na.strings = c(""), stringsAsFactors = T)
summary(epl2)
str(epl2)
library(gmodels)
library(ggplot2)
library(reshape2)
library(e1071)
library(pscl)
library(caret)
epl3 = epl2[,-2]
epl4 = epl3[,-6]
str(epl3)

index <- sample(1:dim(epl4)[1], dim(epl4)[1] * .80, replace=FALSE)
training <- epl4[index, ]
testing <- epl4[-index, ]

summary(epl4)
str(epl4)

logit <- glm(GreaterAverageMrkt ~.,family=binomial(link='logit'),data=training)
summary(logit)

logit.prediction <- predict(logit,newdata=testing,type='response')
results.logit <- as.factor(ifelse(logit.prediction > 0.5,"Yes","No"))

confusionMatrix(results.logit,testing$GreaterAverageMrkt,positive = "Yes")

n <- sapply(epl4, function(x) {is.numeric(x)})
n

numerics <-epl4[, n]
summary(numerics)

normalise <- function(x) { return ((x - min(x)) / (max(x) - min(x))) }
numericsNormal <- normalise(numerics)
summary(numericsNormal)

epl4KNN <- numericsNormal
#epl4KNN <- epl4[, !n]
#epl4KNN <- cbind(epl4KNN, numericsNormal)
summary(epl4KNN)

index <- sample(1:nrow(epl4KNN), nrow(epl4KNN) * .8, replace=FALSE)
kNNTraining <- epl4KNN[index, ]
kNNTesting <- epl4KNN[-index, ]
marketvalueTrain <- epl4[index,]$GreaterAverageMrkt
marketvalueTest <- epl4[-index,]$GreaterAverageMrkt
summary(marketvalueTrain)

k1 <- round(sqrt(dim(kNNTraining)[1])) #sqrt of number of instances
k2 <- round(sqrt(dim(kNNTraining)[2])) #sqrt of number of attributes
k3 <- 7

library(class)
knn1 <- knn(train = kNNTraining, test = kNNTesting, cl = marketvalueTrain, k=k1)
knn2 <- knn(train = kNNTraining, test = kNNTesting, cl = marketvalueTrain, k=k2)
knn3 <- knn(train = kNNTraining, test = kNNTesting, cl = marketvalueTrain, k=k3)
str(knn1)
confusionMatrix(knn1,marketvalueTest,positive = "Yes")
confusionMatrix(knn2,marketvalueTest,positive = "Yes")
confusionMatrix(knn3,marketvalueTest,positive = "Yes")


