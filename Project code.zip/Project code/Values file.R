epl2 = read.csv("values.csv", header = TRUE, na.strings = c(""), stringsAsFactors = T)
summary(epl2)
library(gmodels)
library(ggplot2)
library(reshape2)

y <- epl2$MarketValueEuros
length(y)
table(y)
#y <- factor(y, levels = c(0,1), labels = c("No", "Yes"))
#table(y)

prop.table((table(y)))
barplot(table(y), main = "Distribution of Market Value", ylab = "Frequency")

set.seed(1337)
index <- sample(1:length(y), length(y) * .25, replace = FALSE)
testing <- y[index]

accumModel <- rep("No", length(testing))
highModel <- rep("No", length(testing))

table(testing, accumModel)
table(testing, highModel)

(highAccuracy <- 1 - mean(highModel != testing))
(accumAccuracy <- 1 -mean(accumModel != testing))

prop.table(table(testing))

acc <- c()
high <-c()

for (i in 1:1000) {
  index <- sample(1:length(y), length(y) * .25, replace = FALSE)
  testing <- y[index]
  #accumModel <- round(runif(length(testing), min=0, max = 1))
  #accumModel <- factor(accumModel, levels = c(0,1), labels = c("No", "Yes"))
  acc[i] <- 1 - mean(accumModel != testing)
  high[i] <- 1 - mean(highModel != testing)
}

results <- data.frame(acc, high)
names(results) <- c("Accumulated", "Highest Value")
summary(results)

ggplot(melt(results), mapping = aes (fill = variable, x = value)) + geom_density (alpha = .5)















CrossTable(epl2$Full.Name, MarketValueEuros)
CrossTable(epl2$MarketValueEuros, prop.chisq = F, prop.c = F, prop.r = F)

library(caret)
cMat <- confusionMatrix(MarketValueEuros, epl2$MarketValueEuros, positive = "Yes")
cMat