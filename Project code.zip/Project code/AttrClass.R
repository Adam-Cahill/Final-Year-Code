epl4 = read.csv("Attributes.csv", header = TRUE, na.strings = c(""), stringsAsFactors = T)
summary(epl4)
str(epl4)
library(gmodels)
library(ggplot2)
library(reshape2)
library(e1071)
library(caret)
library(pscl)
epl4$Overall
str(epl4)

index <- sample(1:dim(epl4)[1], dim(epl4)[1] * .60, replace=FALSE)
training <- epl4[index, ]
testing <- epl4[-index, ]

logit <- glm(Overall ~.,family=binomial(link='logit'),data=training, control = list(maxit = 496))
summary(logit)

logit.prediction <- predict(logit,newdata=testing,type='response')
results.logit <- as.factor(ifelse(logit.prediction > 0.5,"Yes","No"))

confusionMatrix(results.logit,testing$Overall,positive = "Yes")

n <- sapply(epl4, function(x) {is.numeric(x)})
n

numerics <-epl4[, n]
summary(numerics)

normalise <- function(x) { return ((x - min(x)) / (max(x) - min(x))) }
numericsNormal <- normalise(numerics)
summary(numericsNormal)

epl4KNN <- numericsNormal
summary(epl4KNN)

index <- sample(1:nrow(epl4KNN), nrow(epl4KNN) * .8, replace=FALSE)
kNNTraining <- epl4KNN[index, ]
kNNTesting <- epl4KNN[-index, ]
overallTrain <- epl4[index,]$Overall
overallTest <- epl4[-index,]$Overall
summary(overallTrain)

k1 <- round(sqrt(dim(kNNTraining)[1])) #sqrt of number of instances
k2 <- round(sqrt(dim(kNNTraining)[2])) #sqrt of number of attributes
k3 <- 10

library(class)
knn1 <- knn(train = kNNTraining, test = kNNTesting, cl = overallTrain, k=k1)
knn2 <- knn(train = kNNTraining, test = kNNTesting, cl = overallTrain, k=k2)
knn3 <- knn(train = kNNTraining, test = kNNTesting, cl = overallTrain, k=k3)
str(knn1)
confusionMatrix(knn1,overallTest,positive = "Yes")
confusionMatrix(knn2,overallTest,positive = "Yes")
confusionMatrix(knn3,overallTest,positive = "Yes")






