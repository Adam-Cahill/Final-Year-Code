epl = read.csv("EPL_Value.csv", header = TRUE)
summary(epl)
#install.packages("pastecs")
#install.packages("ggpubr")
#install.packages("party")
#install.packages("rpart")
#install.packages("cowplot")
#install.packages("caret")
library(caret)
library(rpart)
library(ggplot2)
library(waffle)
library(extrafont)
library(Hmisc)
library(plyr)
library(dplyr)
library(alluvial)
library(gridExtra)
library(pastecs)
library(ggpubr)
library(party)
library(modelr)
library(cowplot)
library(randomForest)
head(epl)


###########################################################
###########################################################

####Looking at the different market values for players#####

#### Random Forest Tree for Market#########################
pd <- sample(2, nrow(epl), replace = TRUE, prob = c(0.8,0.2))
Train4 <- epl[pd==1,]
Test4 <- epl[pd==2,]

rf <- randomForest(HighestMarketValue.Euros. ~ AccumulatedTransferSum.Euros. + MarketValue.Euros., data = Train4, mtry=2, ntree=2001, importance=TRUE)
rf
plot(rf)

result <- data_frame(Test4$HighestMarketValue.Euros., predict(rf, Test4[,1:11], type = "response"))
result
plot(result)

rfConfusionMatrix <- confusionMatrix(result, Test4, fgl.test[,10])

#Building a Decision tree for the overall market values

#Preparing for decision tree
str(epl)

#Partitioning the data for the decision tree
set.seed(1234)
pd <- sample(2, nrow(epl), replace = TRUE, prob = c(0.8,0.2))
Train1 <- epl[pd==1,]
Test1 <- epl[pd==2,]

tree <- ctree(HighestMarketValue.Euros. ~ ., data = Train1)
tree
plot(tree)

Train_predict1 <- predict(tree,Train1)#,type="response")
table(Train_predict1, Train1$HighestMarketValue.Euros.)
mean(Train_predict1 != Train1$HighestMarketValue.Euros.)^2

######### Validating the model##############################
test_predict1 <- predict(tree, newdata = Test1)#, type = "response")
table(test_predict1, Test1$HighestMarketValue.Euros.)
mean(test_predict1 != Test1$HighestMarketValue.Euros.)^2

print(tree)
plot(tree)
plot(tree, type = "simple")

###########################################################

# Building a residual model for the Market as a whole.
Model <- lm(epl$HighestMarketValue.Euros. ~ epl$AccumulatedTransferSum.Euros. + epl$MarketValue.Euros., data = epl)
Model
resid(Model)

x <-resid(Model)

qqnorm(x)
qqline(x)

shapiro.test(x)

###########################################################

#Testing for normality of the range of market values
shapiro.test(epl$MarketValue.Euros.)

hist(epl$MarketValue.Euros., main = "Market Values")

qqplot(epl$MarketValue.Euros., epl$AccumulatedTransferSum.Euros., main = "Market Vs Acumulated values")
qqnorm(epl$MarketValue.Euros., main = "Market Values")
qqline(epl$MarketValue.Euros.)

############################################################

#Testing for Normality for the Acumulated Market sum
shapiro.test(epl$AccumulatedTransferSum.Euros.)

hist(epl$AccumulatedTransferSum.Euros., main = "Accumulated Sum")

qqnorm(epl$AccumulatedTransferSum.Euros., main = "Acumulates Sum")
qqline(epl$AccumulatedTransferSum.Euros.)

boxplot(epl$MarketValue.Euros., epl$AccumulatedTransferSum.Euros., main = "Market Vs Accumulated")

#############################################################

#Comparing two related samples to one another (Market Value compared to Acumulated Value)
wilcox.test(epl$MarketValue.Euros., epl$AccumulatedTransferSum.Euros., mu=0, alternative = "two.sided", paired = TRUE, conf.int = TRUE, conf.level = 0.95, exact = FALSE)
            
####End of market analysis###################################

####Start of Analyising Age and Pace#########################

###Building Residual model for Age and Pace
  
NModel <- lm(epl$Age ~ epl$Pace, data = epl)          
NModel            
resid(NModel)  

y <-resid(NModel)

qqnorm(y)
qqline(y)

shapiro.test(y)

#############################################################

#Testing for normality of the range in the Age category

shapiro.test(epl$Age)

hist(epl$Age, main = "All ages of players")

qqnorm(epl$Age, main = "All ages of players")
qqline(epl$Age)

qqplot(epl$Age, epl$Pace, main = "Age Vs Pace")

#Comparing two related samples to one another (Age and Pace)
wilcox.test(epl$Pace, epl$Age, mu=0, alternative = "two.sided", paired = TRUE, conf.int = TRUE, conf.level = 0.95, exact = FALSE)

#Testing for Normality for the Pace
shapiro.test(epl$Pace)

hist(epl$Pace, main = "Pace for all players")

qqnorm(epl$Pace, main = "Pace for all players")
qqline(epl$Pace)

boxplot(epl$Age, epl$Pace, main = " Age and Pace for all players")

######### Looking At The player sponsors####################

###Partitioning the data################
sponsorSet <- subset(epl, !is.na(epl$PlayerSponsor))
sponsorSet$PlayerSponsor <- as.factor(sponsorSet$PlayerSponsor)
pd <- sample(2, nrow(sponsorSet), replace = TRUE, prob = c(0.8,0.2))
Train2 <- sponsorSet[pd==1,]
Test2 <- sponsorSet[pd==2,]

#####Building the tree#################
#S2tree <- rpart(PlayerSponsor ~ ., data = Train2, method = "class")
Stree <- ctree(PlayerSponsor ~ ., data = Train2)
plot(Stree)
print(Stree)

Train_predict2 <- predict(Stree, Train2)#, type = "response",)
table(Train_predict2,Train2$PlayerSponsor)

#######Validating the model############
test_predict2 <- predict(Stree, newdata = Test2)#, type = "response" )
table(test_predict2, Test2$PlayerSponsor)

print(Stree)
plot(Stree)
plot(Stree, type = "simple")


########Looking at all of the player heights##################
heightSet <- subset(epl, !is.na(epl$Height))
pd <- sample(2, nrow(heightSet), replace = TRUE, prob = c(0.8,0.2))
Train3 <- heightSet[pd==1,]
Test3 <- heightSet[pd==2,]

Htree <- ctree(Height ~., data = Train3)
plot(Htree)
print(Htree)
plot(Htree, type = "simple")


######Validating the model###########################
test_predict3 <- predict(Htree, newdata = Test3)
table(test_predict3, Test3$Height)

print(Htree)
plot(Htree)
plot(Htree, type = "simple")


#### Random Forest for height#######################

hSet <- subset(epl, !is.na(epl$Height))
pd <- sample(2, nrow(hSet), replace = TRUE, prob = c(0.8,0.2))
Train5 <- hSet[pd==1,]
Test5 <- hSet[pd==2,]

fit.rf <- randomForest(Height ~ ., data = Train5)

str(Train5)












