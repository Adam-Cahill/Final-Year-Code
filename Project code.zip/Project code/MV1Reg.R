library(C50)
library(rpart)
library(rpart.plot)
library(RColorBrewer)
library(caret)
library(ROCR)
library(rattle)

epl5 = read.csv("values2.csv", header = TRUE, na.strings = c(""), stringsAsFactors = T)
epl5$GreaterAverageMrkt = as.factor(epl5$GreaterAverageMrkt)

summary(epl5)
epl5 <- epl5[,-7]
epl5 <- epl5[,-1]

set.seed(28022020)
epl5.train.index <- sample(1:nrow(epl5),ceiling(0.8*nrow(epl5)))
epl5.train <- epl5[epl5.train.index,]
epl5.test <- epl5[-epl5.train.index,]


set.seed(28022020)
epl.train.index <- sample(1:nrow(epl5), ceiling(0.75*nrow(epl5)))
epl.train <- epl5[epl.train.index,]
epl.test <-epl5[-epl.train.index,]

rpart.Control <- rpart.control(
  minsplit = 20,
  xval = 10
)

fit.rpart <- rpart(
  MarketValueEuros ~ .,
  data = epl.train,
  method='anova',
  control = rpart.Control
)

fit.rpart

prp(fit.rpart, faclen = 0, cex = 0.8, extra = 1)

rpart.predict <- predict(
  fit.rpart,
  epl.test[, -1]
)
print(fit.rpart)
fit.rpart$cptable

RMSE(pred = rpart.predict, obs = epl.test$MarketValueEuros)
str(epl.test)
print(rpart.predict)
